"""SisPorto – aplicação web (Flask)."""
from __future__ import annotations

import os
import secrets

from flask import Flask, abort, g, request, session

from . import db as dbmod

VERSAO = "1.6.1"
from . import util


def create_app(config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(
        DATABASE_URL=os.environ.get("DATABASE_URL", "postgresql:///sisporto"),
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        GOOGLE_CLIENT_ID=os.environ.get("GOOGLE_CLIENT_ID", ""),
        GOOGLE_CLIENT_SECRET=os.environ.get("GOOGLE_CLIENT_SECRET", ""),
        DOMINIO_EQUIPE=os.environ.get("DOMINIO_EQUIPE", "portosolucoes.com.br"),
        INTEGRACAO_TOKEN=os.environ.get("INTEGRACAO_TOKEN", ""),
        ADMIN_MASTER=os.environ.get("ADMIN_MASTER", "contato@portosolucoes.com.br").lower(),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SEGURO", "1") == "1",
        PERMANENT_SESSION_LIFETIME=60 * 60 * 12,
        MAX_CONTENT_LENGTH=21 * 1024 * 1024,  # anexos de até 20 MB
    )
    if config:
        app.config.update(config)
    if os.environ.get("ATRAS_DE_PROXY", "1") == "1":  # Cloud Run: https e host corretos nos links
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    app.after_request(dbmod.confirmar)
    app.teardown_appcontext(dbmod.fechar)
    util.registrar_filtros(app)

    # --- proteção CSRF simples (token por sessão em todo POST) -------------
    @app.before_request
    def _csrf():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
        if request.path.startswith("/integracao/"):
            return  # autenticado por X-Token, não por sessão
        if request.method == "POST" and not app.config.get("TESTING_SEM_CSRF"):
            enviado = request.form.get("csrf") or request.headers.get("X-CSRF")
            if not enviado or not secrets.compare_digest(enviado, session["csrf"]):
                abort(400, "Formulário expirado. Recarregue a página.")

    @app.context_processor
    def _ctx():
        from .acessos import pode
        from .relatorios import CATALOGO
        u = g.get("usuario")
        a_aprovar = 0
        if u and u["perfil"] == "admin":
            try:
                a_aprovar = dbmod.db().val("SELECT count(*) FROM apontamentos WHERE status = 'pendente'") or 0
            except dbmod.DatabaseError:
                a_aprovar = 0
        extras_pend = 0
        if u and u["perfil"] == "cliente":
            try:
                extras_pend = dbmod.db().val("""SELECT count(*) FROM horas_extras e JOIN contratos ct ON ct.id = e.contrato_id
                                                 WHERE ct.cliente_id = %s AND e.status = 'pendente'""", [u["cliente_id"]]) or 0
            except dbmod.DatabaseError:
                extras_pend = 0
        return {"csrf": session.get("csrf", ""), "usuario": u, "pode": pode, "versao": VERSAO,
                "catalogo_relatorios": CATALOGO, "a_aprovar": a_aprovar, "extras_pendentes": extras_pend}

    from .auth import bp as auth_bp, carregar_usuario
    from .rotas_equipe import bp as equipe_bp
    from .rotas_portal import bp as portal_bp
    from .email_integracao import bp as email_bp
    from .relatorios import bp as relatorios_bp
    from .anexos import bp as anexos_bp
    from .integracoes import bp as integracoes_bp
    from .rotas_gestao import bp as gestao_bp
    from .rotas_contratos import bp as contratos_bp
    from .rotas_admin import bp as adm_bp
    from .rotas_extras import bp as extras_bp
    from .rotas_conhecimento import bp as kb_bp

    app.before_request(carregar_usuario)
    app.register_blueprint(auth_bp)
    app.register_blueprint(equipe_bp)
    app.register_blueprint(portal_bp, url_prefix="/portal")
    app.register_blueprint(email_bp, url_prefix="/integracao/email")
    app.register_blueprint(relatorios_bp, url_prefix="/relatorios")
    app.register_blueprint(anexos_bp)
    app.register_blueprint(integracoes_bp)
    app.register_blueprint(gestao_bp)
    app.register_blueprint(contratos_bp)
    app.register_blueprint(adm_bp)
    app.register_blueprint(extras_bp)
    app.register_blueprint(kb_bp)

    @app.get("/saude")
    def saude():
        dbmod.db().val("SELECT 1")
        return {"ok": True, "driver": dbmod._DRIVER}

    @app.get("/marca/logo")
    def logo():
        from flask import Response, send_from_directory
        try:
            row = dbmod.db().one("SELECT arquivo, tipo_mime, atualizado_em FROM configuracoes WHERE chave = 'logo'")
        except dbmod.DatabaseError:  # banco ainda sem a migração
            row = None
        if not row:
            r = send_from_directory(app.static_folder, "logo-padrao.png", max_age=300)
        else:
            r = Response(bytes(row["arquivo"]), mimetype=row["tipo_mime"])
            r.headers["Cache-Control"] = "public, max-age=300"
        r.headers["X-Content-Type-Options"] = "nosniff"
        return r

    @app.errorhandler(dbmod.DatabaseError)
    def _erro_banco(e):
        """Regras do banco viram aviso amigável (ex.: período de horas fechado)."""
        from flask import flash, redirect
        if "PERIODO_FECHADO" in str(e):
            conn = g.get("db")
            if conn is not None:
                conn.rollback()
            flash("Este período de horas está fechado: lançamentos não podem ser criados, alterados ou excluídos.",
                  "erro")
            volta = request.referrer or "/"
            return redirect(volta if volta.startswith(request.host_url) or volta.startswith("/") else "/")
        raise e

    @app.errorhandler(403)
    def _proibido(e):
        return util.pagina_erro("Acesso negado", "Você não tem permissão para ver esta página."), 403

    @app.errorhandler(404)
    def _nao_encontrado(e):
        return util.pagina_erro("Não encontrado", "A página ou registro não existe."), 404

    @app.errorhandler(413)
    def _grande(e):
        from flask import flash, redirect
        flash("Arquivo maior que 20 MB não é aceito. Envie o link de uma pasta do Google Drive (ou similar) "
              "na mensagem do chamado.", "erro")
        volta = request.referrer or "/"
        if not volta.startswith(request.host_url):
            volta = "/"
        return redirect(volta)

    @app.errorhandler(400)
    def _invalido(e):
        return util.pagina_erro("Requisição inválida", getattr(e, "description", "")), 400

    from .cli import registrar as registrar_cli
    registrar_cli(app)
    return app
